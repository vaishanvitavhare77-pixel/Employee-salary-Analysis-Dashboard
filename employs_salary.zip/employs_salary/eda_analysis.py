
import pandas as pd

df = pd.read_csv("employee_salary.csv")

print("\nFirst 5 Records:")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

print("\nColumn Information:")
print(df.info())

print("\nMissing Values:")
print(df.isnull().sum())

print("\nStatistical Summary:")
print(df.describe())

print("\nAverage Salary:")
print(round(df["Salary_INR"].mean(), 2))

print("\nHighest Salary:")
print(df["Salary_INR"].max())

print("\nLowest Salary:")
print(df["Salary_INR"].min())

print("\nAverage Salary by Department:")
print(
    df.groupby("Department")["Salary_INR"]
    .mean()
    .sort_values(ascending=False)
)


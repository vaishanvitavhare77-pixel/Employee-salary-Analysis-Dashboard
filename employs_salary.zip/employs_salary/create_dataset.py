
import pandas as pd
import numpy as np

np.random.seed(42)

departments = [
    "IT",
    "HR",
    "Finance",
    "Marketing",
    "Sales",
    "Operations"
]

job_titles = [
    "Data Analyst",
    "Software Engineer",
    "HR Executive",
    "Accountant",
    "Marketing Executive",
    "Sales Executive",
    "Project Manager",
    "Business Analyst"
]

genders = ["Male", "Female"]

data = {
    "Employee_ID": range(1001, 1301),

    "Age": np.random.randint(22, 60, 300),

    "Gender": np.random.choice(
        genders, 300
    ),

    "Department": np.random.choice(
        departments, 300
    ),

    "Job_Title": np.random.choice(
        job_titles, 300
    ),

    "Experience_Years": np.random.randint(
        0, 21, 300
    )
}

df = pd.DataFrame(data)

department_bonus = {
    "IT": 150000,
    "HR": 30000,
    "Finance": 80000,
    "Marketing": 60000,
    "Sales": 50000,
    "Operations": 40000
}

df["Salary_INR"] = (
    250000
    + df["Experience_Years"] * 65000
    + df["Department"].map(department_bonus)
    + np.random.randint(-80000, 120000, 300)
)

df["Salary_INR"] = df["Salary_INR"].clip(
    lower=200000
)

df.to_csv("employee_salary.csv", index=False)

print("Dataset created successfully!")
print("Total employees:", len(df))
print(df.head())


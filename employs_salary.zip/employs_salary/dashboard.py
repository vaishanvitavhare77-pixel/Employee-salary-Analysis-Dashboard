
import pandas as pd
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go

# ----------------------------------
# 1. Load the dataset
# ----------------------------------

df = pd.read_csv("employee_salary.csv")

# ----------------------------------
# 2. Prepare summary information
# ----------------------------------

total_employees = len(df)

average_salary = df["Salary_INR"].mean()

highest_salary = df["Salary_INR"].max()

average_experience = df["Experience_Years"].mean()

# ----------------------------------
# 3. Set a consistent color scheme
# ----------------------------------

colors = px.colors.qualitative.Set2

# ----------------------------------
# 4. Create the charts
# ----------------------------------

# Chart 1: Average salary by department
department_salary = (
    df.groupby("Department", as_index=False)
    ["Salary_INR"].mean()
    .sort_values("Salary_INR", ascending=False)
)

fig1 = px.bar(
    department_salary,
    x="Department",
    y="Salary_INR",
    color="Department",
    color_discrete_sequence=colors,
    title="1. Average Salary by Department",
    labels={
        "Salary_INR": "Average Annual Salary (INR)",
        "Department": "Department"
    },
    hover_data={
        "Salary_INR": ":,.0f"
    }
)

fig1.update_layout(showlegend=False)


# Chart 2: Salary trend by experience
experience_salary = (
    df.groupby("Experience_Years", as_index=False)
    ["Salary_INR"].mean()
)

fig2 = px.line(
    experience_salary,
    x="Experience_Years",
    y="Salary_INR",
    markers=True,
    title="2. Average Salary by Experience",
    labels={
        "Experience_Years": "Years of Experience",
        "Salary_INR": "Average Salary (INR)"
    }
)


# Chart 3: Experience vs salary
fig3 = px.scatter(
    df,
    x="Experience_Years",
    y="Salary_INR",
    color="Department",
    hover_data=["Job_Title", "Age", "Gender"],
    title="3. Experience vs Employee Salary",
    labels={
        "Experience_Years": "Years of Experience",
        "Salary_INR": "Annual Salary (INR)"
    }
)


# Chart 4: Salary distribution
fig4 = px.histogram(
    df,
    x="Salary_INR",
    nbins=20,
    color_discrete_sequence=["#636EFA"],
    title="4. Distribution of Employee Salaries",
    labels={
        "Salary_INR": "Annual Salary (INR)",
        "count": "Number of Employees"
    }
)


# Chart 5: Salary variation by department
fig5 = px.box(
    df,
    x="Department",
    y="Salary_INR",
    color="Department",
    color_discrete_sequence=colors,
    title="5. Salary Variation by Department",
    labels={
        "Department": "Department",
        "Salary_INR": "Annual Salary (INR)"
    }
)

fig5.update_layout(showlegend=False)


# Chart 6: Correlation heatmap
numeric_columns = [
    "Age",
    "Experience_Years",
    "Salary_INR"
]

correlation = df[numeric_columns].corr()

fig6 = px.imshow(
    correlation,
    text_auto=".2f",
    aspect="auto",
    color_continuous_scale="RdBu_r",
    zmin=-1,
    zmax=1,
    title="6. Correlation Between Numerical Variables"
)


# ----------------------------------
# 5. Create the dashboard layout
# ----------------------------------

figures = [fig1, fig2, fig3, fig4, fig5, fig6]

for fig in figures:
    fig.update_layout(
        template="plotly_white",
        font=dict(
            family="Arial",
            size=12
        ),
        title_font_size=18,
        margin=dict(
            l=50,
            r=30,
            t=70,
            b=50
        ),
        height=420
    )

# ----------------------------------
# 6. Create the HTML dashboard
# ----------------------------------

html_parts = []

html_parts.append("""
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">

<title>Employee Salary Analysis Dashboard</title>

<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f7fb;
    margin: 0;
    padding: 20px;
    color: #222;
}

header {
    background: #243b55;
    color: white;
    padding: 25px;
    border-radius: 10px;
    text-align: center;
}

.metrics {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    margin: 20px 0;
}

.card {
    background: white;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    box-shadow: 0 2px 7px #00000010;
}

.card h2 {
    color: #243b55;
    margin-bottom: 5px;
}

.chart {
    background: white;
    margin: 20px 0;
    padding: 10px;
    border-radius: 10px;
}

.note {
    font-size: 13px;
    color: #555;
    text-align: center;
}

@media (max-width: 800px) {
    .metrics {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>
</head>

<body>

<header>
    <h1>Employee Salary Analysis Dashboard</h1>
    <p>Explore salary patterns, experience, and department comparisons.</p>
</header>
""")

# ----------------------------------
# 7. Display key performance indicators
# ----------------------------------

html_parts.append(f"""
<div class="metrics">

<div class="card">
<h3>Total Employees</h3>
<h2>{total_employees:,}</h2>
</div>

<div class="card">
<h3>Average Salary</h3>
<h2>₹{average_salary:,.0f}</h2>
</div>

<div class="card">
<h3>Highest Salary</h3>
<h2>₹{highest_salary:,.0f}</h2>
</div>

<div class="card">
<h3>Average Experience</h3>
<h2>{average_experience:.1f} years</h2>
</div>

</div>
""")

# ----------------------------------
# 8. Add all interactive charts
# ----------------------------------

for i, fig in enumerate(figures):
    chart_html = fig.to_html(
        full_html=False,
        include_plotlyjs="cdn" if i == 0 else False
    )

    html_parts.append(
        f'<div class="chart">{chart_html}</div>'
    )

# ----------------------------------
# 9. Add the dataset note
# ----------------------------------

html_parts.append("""
<div class="note">
<p>
Dataset note: This dashboard uses synthetic employee data
created for educational and demonstration purposes.
</p>
</div>

</body>
</html>
""")

# ----------------------------------
# 10. Save the dashboard
# ----------------------------------

with open(
    "employee_salary_dashboard.html",
    "w",
    encoding="utf-8"
) as file:

    file.write("\n".join(html_parts))

print("Dashboard created successfully!")

print(
    "Open employee_salary_dashboard.html "
    "in your web browser."
)
